import { Component, OnInit, OnDestroy } from '@angular/core';
import { interval, Subscription, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

  private objSubscription : Subscription;
  constructor() { }

  ngOnInit() {
    //this.objSubscription = interval(1000).subscribe( data => console.log(data));
    const customIntervalObservable = Observable.create(observer => {
      let count = 0 ;
      setInterval(() => {
        observer.next(count);
        if(count > 3){
          observer.error(new Error('Count is greater than 3'));
        }else if(count == 10){
          observer.complete();
        }
        count++;
      }, 1000);
    });

    this.objSubscription = customIntervalObservable
    .pipe(map((data : number) => 'Round' + (data + 1)))
    .subscribe( data => console.log(data)
    ,error => alert(error.message)
    ,() => console.log('Completed')
    );

  }

  ngOnDestroy() {
    this.objSubscription.unsubscribe();
  }

}
